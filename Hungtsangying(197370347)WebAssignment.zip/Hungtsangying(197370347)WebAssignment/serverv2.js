var http = require('http');
var fs = require("fs");
var qs = require('querystring');

var MongoClient = require('mongodb').MongoClient;

var dbUrl = "mongodb://localhost:27017/";
var  userloginname = "";



http.createServer(function(request, response) {
   
	if(request.url === "/index"){
		sendFileContent(response, "web.html", "text/html");
	}
	else if(request.url === "/web"){
		console.log("Requested URL is url" +request.url);
		response.writeHead(200, {'Content-Type': 'text/html'});
		response.write('<b>Hey there!</b><br /><br />This is the default response. Requested URL is: ' + request.url);
	}
    else if(request.url === "/login"){
		sendFileContent(response, "contact.html", "text/html");
	}else if(request.url === "/mydate"){
        sendFileContent(response, "preferencesv2.html", "text/html");
       
	}
    else if(request.url === "/member3"){
        sendFileContent(response, "indexv2.html", "text/html");
       
	}else if(request.url === "/member4"){
        sendFileContent(response, "indexv5.html", "text/html");
       
	}else if(request.url === "/member"){
        sendFileContent(response, "indexv3.html", "text/html");
       
	}else if(request.url === "/member2"){
        sendFileContent(response, "indexv4.html", "text/html");
       
	}else if(request.url === "/nomember"){
        sendFileContent(response, "manage-usersv2.html", "text/html");
       
	}else if(request.url === "/nomember?fbclid=IwAR1X7UnnxP6ALFoWwJmaCnRFwiSf6ZqWbeZlGh6L1zFi_YytccNJnQX2HLs"){
        sendFileContent(response, "manage-usersv2.html", "text/html");
       
	}else if(request.url === "/nomember2"){
        sendFileContent(response, "manage-usersv3.html", "text/html");
       
	}else if(request.url === "/nomember3"){
        sendFileContent(response, "manage-usersv4.html", "text/html");
       
	}
	else if(request.url === "/contact"){
        sendFileContent(response, "register.html", "text/html");
       
	}
	else if(request.url === "/"){
        sendFileContent(response, "index.html", "text/html");
       
	}
	else if(request.url === "/about"){
        sendFileContent(response, "about.html", "text/html");
       
	}
    else if(request.url==="/test"){
              
       
   
              
	}else if (request.url === "/getname")
		{
			
				if (request.method === "POST") 
				{
					console.log("action = getname");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						
						
						info=formData.split("&");
						
						
						return request.on('end', function() {
							
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								
										var query = userloginname;
										//console.log(query);
										//console.log(userloginname);
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
										//console.log(result);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);
                                        });
							
							});
                            
                            
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}	else if (request.url === "/passdata")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = pass");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						console.log(obj.pass);
						
						
						info=formData.split("&");
						
						/*for(i=0;i<info.length;i++){
						
						//var d = info[i].split("=");
						
						if(i===0){
							var d = info[i].split("=");	
						}else if(i===1){
							var e = info[i].split("=");	
						}else if(i===2){
							var f = info[i].split("=");	
						}
						}
						console.log(d[0]);
						console.log(d[1]);
						console.log(e[0]);
						console.log(e[1]);*/
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								//dbo.collection("login").count(myobj, function(err, count){
									//console.log(err, count);
									//finalcount = count;
								userloginname = { user: obj.user };
										dbo.collection("login").insertOne(myobj, function(err, res) {
											if (err) throw err;
											console.log("info inserted");
											//console.log(response);
											//if(result.length > 0){
											db.close();
											return response.end('{"result":"ok"}');
										//}
											//db.close();
											//return response.end('{"result":"ok"}');
										});
										
										//return res.end(msg);
										
										//var query = { user: obj.user };
                                        //dbo.collection("login").find(query).toArray(function(err, result) {
                                        //if (err) throw err;
                                        //console.log(result);
                                        //db.close();
                                        //});
							
								//});
							});
                            
                            
                            ////////////////////
                          //return response.end("fail");
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}else if (request.url === "/getuserdata")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = getuserdata");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						console.log(obj.pass);
						
						
						info=formData.split("&");
					
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								
										var query = { user: obj.user };
										userloginname = { user: obj.user };
										console.log(query);
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
										console.log(result.length);
										if(result.length==0){
											
											userloginname = { user: obj.user };
										dbo.collection("login").insertOne(myobj, function(err, res) {
											if (err) throw err;
											console.log("info inserted");
											//console.log(response);
											//if(result.length > 0){
											db.close();
											return response.end('{"result":"ok"}');
										//}
											//db.close();
											//return response.end('{"result":"ok"}');
										});
											
										}else{
											var returnresult=JSON.stringify(result)
										    return response.end(returnresult);
										}
                                        });
							});
                            
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}else if (request.url === "/getdata")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = getdata");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						console.log(obj.pass);
						
						info=formData.split("&");
					
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								
										var query = { "user": obj.user };
										userloginname = { user: obj.user };
										console.log(query);
										//console.log(userloginname);
										//console.log({ user: obj.user });
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
										console.log(result);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);
										//return response.end("success");
										//console.log(result+"789");
                                        });
							
								//});
							});
                            
                            
                            ////////////////////
							//return response.end("success");
                          //return response.end("fail");
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}else if (request.url === "/getpass")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = getdata");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						console.log(obj.pass);
						
						info=formData.split("&");
					
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								
										var query = { "password": obj.user };
										userloginname = { user: obj.user };
										console.log(query);
										//console.log(userloginname);
										//console.log({ user: obj.user });
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
										console.log(result);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);
										//return response.end("success");
										//console.log(result+"789");
                                        });
							
								//});
							});
                            
                            
                            ////////////////////
							//return response.end("success");
                          //return response.end("fail");
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}else if (request.url === "/checkdata")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = checkdata");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						console.log(obj.pass);
						
						
						info=formData.split("&");
						
						/*for(i=0;i<info.length;i++){
						
						//var d = info[i].split("=");
						
						if(i===0){
							var d = info[i].split("=");	
						}else if(i===1){
							var e = info[i].split("=");	
						}else if(i===2){
							var f = info[i].split("=");	
						}
						}
						console.log(d[0]);
						console.log(d[1]);
						console.log(e[0]);
						console.log(e[1]);*/
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								
										var query = { user: obj.user };
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
										console.log(result);
										if(result.length==0){
											var query2 = { email: obj.email };
										dbo.collection("login").find(query2).toArray(function(err, result) {
                                        if (err) throw err;
										console.log(result);
										if(result.length==0){
											userloginname = { user: obj.user };
										dbo.collection("login").insertOne(myobj, function(err, result) {
											if (err) throw err;
											console.log("info inserted");
											db.close();
											return response.end('{"result":"ok"}');
										
										});
										}else{
											var returnresult=JSON.stringify(result)
											return response.end(returnresult);
										}
                                        });
										}else{
											var returnresult=JSON.stringify(result)
											return response.end(returnresult);
										}
                                        });
										
							
								//});
							});
                            
                            
                            ////////////////////
							//return response.end("success");
                          //return response.end("fail");
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}else if (request.url === "/addfavorite")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = addfavorite");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						console.log(obj.gameid);
						console.log(obj.gamescore);
						
						info=formData.split("&");
						
						/*for(i=0;i<info.length;i++){
						
						//var d = info[i].split("=");
						
						if(i===0){
							var d = info[i].split("=");	
						}else if(i===1){
							var e = info[i].split("=");	
						}else if(i===2){
							var f = info[i].split("=");	
						}
						}
						console.log(d[0]);
						console.log(d[1]);
						console.log(e[0]);
						console.log(e[1]);*/
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								var myobj = {"gameid" : obj.gameid, "gamescore" : obj.gamescore, "pc" : obj.pc, "ps4" : obj.ps4, "mobile" : obj.mobile, "gamename" : obj.gamename, "gamedate" : obj.gamedate};
								//dbo.collection("login").count(myobj, function(err, count){
									//console.log(err, count);
									//finalcount = count;
									
								
										dbo.collection(obj.user).insertOne(myobj, function(err, result) {
											if (err) throw err;
											console.log( obj.user + "added");
											db.close();
											var returnresult=JSON.stringify(result)
											return response.end(returnresult);
										});
										
										//return res.end(msg);
										
										//var query = { user: obj.user };
                                        //dbo.collection("login").find(query).toArray(function(err, result) {
                                        //if (err) throw err;
                                        //console.log(result);
                                        //db.close();
                                        //});
							
								//});
							});
                            
                            
                            ////////////////////
                          //return response.end("fail");
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}else if (request.url === "/getfavorite")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = getfavorite");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						
						
						info=formData.split("&");
						
						/*for(i=0;i<info.length;i++){
						
						//var d = info[i].split("=");
						
						if(i===0){
							var d = info[i].split("=");	
						}else if(i===1){
							var e = info[i].split("=");	
						}else if(i===2){
							var f = info[i].split("=");	
						}
						}
						console.log(d[0]);
						console.log(d[1]);
						console.log(e[0]);
						console.log(e[1]);*/
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								//var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								//dbo.collection("login").count(myobj, function(err, count){
									//console.log(err, count);
									//finalcount = count;
								
										//dbo.collection("login").insertOne(myobj, function(err, res) {
											//if (err) throw err;
											//console.log("info inserted");
											//db.close();
										//});
										//return res.end(msg);
										
										/*var query = { user: obj.user };
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
                                        console.log(result);
                                        db.close();
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);*/
										
										/*dbo.collection("login").count({"user" : obj.user}, function(err, count){
								        console.log(err, count);
								        finalcount = count;
										console.log(finalcount);
								        if(finalcount > 0)
								        {
									        if(err) throw err;
									        console.log("user exist");
									        db.close();
								        	return response.end("fail");
											
								        }*/
										var query = { gameid: obj.gameid };
										//userloginname = (obj.user);
										console.log(query);
										console.log({ user: obj.user });
										//console.log(userloginname);
                                        dbo.collection(obj.user).find(query).toArray(function(err, result) {
                                        if (err) throw err;
										console.log(result.length);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);

                                        });
							
							});
                            
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}else if (request.url === "/delfavorite")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = delfavorite");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						
						
						info=formData.split("&");
						
						/*for(i=0;i<info.length;i++){
						
						//var d = info[i].split("=");
						
						if(i===0){
							var d = info[i].split("=");	
						}else if(i===1){
							var e = info[i].split("=");	
						}else if(i===2){
							var f = info[i].split("=");	
						}
						}
						console.log(d[0]);
						console.log(d[1]);
						console.log(e[0]);
						console.log(e[1]);*/
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								//var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								//dbo.collection("login").count(myobj, function(err, count){
									//console.log(err, count);
									//finalcount = count;
								
										//dbo.collection("login").insertOne(myobj, function(err, res) {
											//if (err) throw err;
											//console.log("info inserted");
											//db.close();
										//});
										//return res.end(msg);
										
										/*var query = { user: obj.user };
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
                                        console.log(result);
                                        db.close();
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);*/
										
										/*dbo.collection("login").count({"user" : obj.user}, function(err, count){
								        console.log(err, count);
								        finalcount = count;
										console.log(finalcount);
								        if(finalcount > 0)
								        {
									        if(err) throw err;
									        console.log("user exist");
									        db.close();
								        	return response.end("fail");
											
								        }*/
										var query = { gameid: obj.gameid };
                                        dbo.collection(obj.user).deleteOne(query, function(err, result) {
                                        if (err) throw err;
										//console.log(result);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);

                                        });
							
							});
                            
						
						});
					});
				}else{
                    console.log("here");
                }
		}else if (request.url === "/updatapass")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = update pass");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						
						
						info=formData.split("&");
						
						/*for(i=0;i<info.length;i++){
						
						//var d = info[i].split("=");
						
						if(i===0){
							var d = info[i].split("=");	
						}else if(i===1){
							var e = info[i].split("=");	
						}else if(i===2){
							var f = info[i].split("=");	
						}
						}
						console.log(d[0]);
						console.log(d[1]);
						console.log(e[0]);
						console.log(e[1]);*/
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								//var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								//dbo.collection("login").count(myobj, function(err, count){
									//console.log(err, count);
									//finalcount = count;
								
										//dbo.collection("login").insertOne(myobj, function(err, res) {
											//if (err) throw err;
											//console.log("info inserted");
											//db.close();
										//});
										//return res.end(msg);
										
										/*var query = { user: obj.user };
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
                                        console.log(result);
                                        db.close();
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);*/
										
										/*dbo.collection("login").count({"user" : obj.user}, function(err, count){
								        console.log(err, count);
								        finalcount = count;
										console.log(finalcount);
								        if(finalcount > 0)
								        {
									        if(err) throw err;
									        console.log("user exist");
									        db.close();
								        	return response.end("fail");
											
								        }*/
										var myquery = { "password": obj.user };
										//console.log(myquery+"serv44");
                                        var newvalues = { $set: { "password": obj.pass } };
										//console.log(newvalues+"serv44");
                                        dbo.collection("login").updateOne(myquery, newvalues, function(err, result) {
                                        if (err) throw err;
										//console.log(result);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										
										var returnresult=JSON.stringify(result)
										//console.log(returnresult+"serv44");
										return response.end(returnresult);

                                        });
							
							});
                            
						
						});
					});
				}else{
                    console.log("here");
                }
		}else if (request.url === "/editfavorite")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = editfavorite");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						
						
						info=formData.split("&");
						
						/*for(i=0;i<info.length;i++){
						
						//var d = info[i].split("=");
						
						if(i===0){
							var d = info[i].split("=");	
						}else if(i===1){
							var e = info[i].split("=");	
						}else if(i===2){
							var f = info[i].split("=");	
						}
						}
						console.log(d[0]);
						console.log(d[1]);
						console.log(e[0]);
						console.log(e[1]);*/
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								//var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								//dbo.collection("login").count(myobj, function(err, count){
									//console.log(err, count);
									//finalcount = count;
								
										//dbo.collection("login").insertOne(myobj, function(err, res) {
											//if (err) throw err;
											//console.log("info inserted");
											//db.close();
										//});
										//return res.end(msg);
										
										/*var query = { user: obj.user };
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
                                        console.log(result);
                                        db.close();
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);*/
										
										/*dbo.collection("login").count({"user" : obj.user}, function(err, count){
								        console.log(err, count);
								        finalcount = count;
										console.log(finalcount);
								        if(finalcount > 0)
								        {
									        if(err) throw err;
									        console.log("user exist");
									        db.close();
								        	return response.end("fail");
											
								        }*/
										console.log(obj.gameid);
										var myquery = { gameid: obj.gameid };
										//console.log(myquery+"444server");
                                        var newvalues = { $set: { gamescore: obj.gamescore, "pc" : obj.pc, "ps4" : obj.ps4, "mobile" : obj.mobile } };
                                        dbo.collection(obj.user).updateOne(myquery, newvalues, function(err, result) {
                                        if (err) throw err;
										//console.log(result);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										
										var returnresult=JSON.stringify(result)
										//console.log(returnresult+"serv44");
										return response.end(returnresult);

                                        });
							
							});
                            
						
						});
					});
				}else{
                    console.log("here");
                }
		}else if (request.url === "/getallfavorite")
		{
			
				
				if (request.method === "POST") 
				{
					console.log("action = getallfavorite");
					formData = '';
					msg = '';
                   
					return request.on('data', function(data) {
						formData += data;
						console.log("form data2="+ formData);
						
						var obj=JSON.parse(formData);
						
						console.log(obj.user);
						
						
						info=formData.split("&");
						
						
						return request.on('end', function() {
							/////////////////////
                            MongoClient.connect(dbUrl, function(err, db) {
								var finalcount;
								if (err) throw err;
								var dbo = db.db("dbv1");
								//var myobj = {"user" : "jjloginname", "password" : "apple", "email" : "aaa@bbb.ccc"};
								//var myobj = {"user" : d[1], "password" : e[1], "email" : f[1]};
								//var myobj = {"user" : obj.user, "password" : obj.pass, "email" : obj.email};
								//dbo.collection("login").count(myobj, function(err, count){
									//console.log(err, count);
									//finalcount = count;
								
										//dbo.collection("login").insertOne(myobj, function(err, res) {
											//if (err) throw err;
											//console.log("info inserted");
											//db.close();
										//});
										//return res.end(msg);
										
										/*var query = { user: obj.user };
                                        dbo.collection("login").find(query).toArray(function(err, result) {
                                        if (err) throw err;
                                        console.log(result);
                                        db.close();
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);*/
										
										/*dbo.collection("login").count({"user" : obj.user}, function(err, count){
								        console.log(err, count);
								        finalcount = count;
										console.log(finalcount);
								        if(finalcount > 0)
								        {
									        if(err) throw err;
									        console.log("user exist");
									        db.close();
								        	return response.end("fail");
											
								        }*/
										//var query = { gameid: obj.gameid };
                                        dbo.collection(obj.user).find({}).toArray(function(err, result) {
                                        if (err) throw err;
										console.log(result.length);
										if(result.length==0){
											db.close();
											return response.end('{"result":"no"}');
										}
										
										var returnresult=JSON.stringify(result)
										return response.end(returnresult);

                                        });
							
							});
                            
						
						});
					});
				}else{
                    console.log("here");
                }
			
			
		}	
    else if(/^\/[a-zA-Z0-9\/_.-]*.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if(/^\/[a-zA-Z0-9\/_.-]*.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}else if(/^\/[-a-zA-Z0-9\/_.-]*.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
    else if(/^\/[-a-zA-Z0-9\/_.-]*.jpg$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/jpg");
	}
    else if(/^\/[-a-zA-Z0-9\/_.-]*.png$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/png");
	}
	else if(/^\/[-a-zA-Z0-9\/_.-]*.ttf$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/ttf");
	}
	else if(/^\/[-a-zA-Z0-9\/_.-]*.woff$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/woff");
	}
	else if(/^\/[-a-zA-Z0-9\/_.-]*.woff2$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/woff2");
	}
	else if(/^\/[-a-zA-Z0-9\/_.-]*.css.map$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css.map");
	}
	else{
		console.log("Requested URL is: " + request.url);
		response.end();
	}
}).listen(9999)

function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}